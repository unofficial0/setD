﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerException
{
    public class Cust_Exception : ApplicationException
    {
        public Cust_Exception(string Message) : base(Message)
        {

        }
    }
}
